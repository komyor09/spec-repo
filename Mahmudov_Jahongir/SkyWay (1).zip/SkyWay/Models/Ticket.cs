namespace SkyWay.Models;

public class Ticket
{
    public string Code { get; set; } = "";
    public int FlightId { get; set; }
    public string PassengerName { get; set; } = "";
    public string Passport { get; set; } = "";
    public TravelClass Class { get; set; }
    public string Seat { get; set; } = "";
    public decimal Price { get; set; }
    public DateTime PurchasedAt { get; set; }
    public bool Cancelled { get; set; }
}
