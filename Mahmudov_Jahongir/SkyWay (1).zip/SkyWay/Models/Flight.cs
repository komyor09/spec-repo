namespace SkyWay.Models;

public enum TravelClass { Economy, Business }

public class Flight
{
    public int Id { get; set; }
    public string Number { get; set; } = "";
    public string Airline { get; set; } = "";
    public string From { get; set; } = "";
    public string To { get; set; } = "";
    public DateTime Departure { get; set; }
    public DateTime Arrival { get; set; }
    public decimal EconomyPrice { get; set; }
    public decimal BusinessPrice { get; set; }
    public int EconomySeats { get; set; }
    public int BusinessSeats { get; set; }

    public decimal PriceFor(TravelClass c) =>
        c == TravelClass.Economy ? EconomyPrice : BusinessPrice;

    public override string ToString() =>
        $"#{Id} {Number}  {From} → {To}  {Departure:dd.MM.yyyy HH:mm} – {Arrival:HH:mm}  " +
        $"Эконом {EconomyPrice:N0} ₽ | Бизнес {BusinessPrice:N0} ₽";
}
