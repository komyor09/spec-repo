using System.Text.Json.Serialization;
using SkyWay.Models;
using SkyWay.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
builder.Services.AddSingleton(Database.Load());
builder.Services.AddSingleton<BookingService>();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

var gate = new object(); // покупка и возврат — по одному, чтобы не продать одно место дважды
var api = app.MapGroup("/api");

api.MapGet("/cities", (Database db) =>
    db.Flights.SelectMany(f => new[] { f.From, f.To }).Distinct().Order());

api.MapGet("/routes", (Database db) =>
    db.Flights.Where(f => f.Departure > DateTime.Now)
        .GroupBy(f => new { f.From, f.To })
        .Select(g => new { g.Key.From, g.Key.To, Price = g.Min(f => f.EconomyPrice) })
        .OrderBy(r => r.Price));

api.MapGet("/flights", (BookingService s, string? from, string? to, DateTime? date) =>
    s.Search(from, to, date).Take(100).Select(f => new
    {
        f.Id, f.Number, f.Airline, f.From, f.To, f.Departure, f.Arrival, f.EconomyPrice, f.BusinessPrice,
        EconomyFree = s.FreeSeats(f, TravelClass.Economy).Count,
        BusinessFree = s.FreeSeats(f, TravelClass.Business).Count
    }));

api.MapGet("/flights/{id:int}/seats", (BookingService s, int id, TravelClass cls) =>
{
    var f = s.GetFlight(id);
    if (f is null) return Results.NotFound();
    var free = s.FreeSeats(f, cls).ToHashSet();
    var (prefix, count) = cls == TravelClass.Economy ? ("E", f.EconomySeats) : ("B", f.BusinessSeats);
    return Results.Ok(Enumerable.Range(1, count).Select(i => new { id = $"{prefix}{i}", free = free.Contains($"{prefix}{i}") }));
});

api.MapPost("/tickets", (BookingService s, BuyRequest r) =>
{
    try
    {
        lock (gate)
        {
            var f = s.GetFlight(r.FlightId) ?? throw new InvalidOperationException("Рейс не найден.");
            return Results.Ok(new { ticket = s.Buy(f, r.Name, r.Passport, r.Class, r.Seat), flight = f });
        }
    }
    catch (Exception ex) when (ex is ArgumentException or InvalidOperationException)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

api.MapPost("/tickets/lookup", (BookingService s, PassportRequest r) =>
    s.FindByPassport(r.Passport).Select(t => new { ticket = t, flight = s.GetFlight(t.FlightId) }));

api.MapPost("/tickets/{code}/cancel", (BookingService s, string code, PassportRequest r) =>
{
    try
    {
        lock (gate) return Results.Ok(new { refund = s.Cancel(code, r.Passport) });
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
});

app.Run("http://localhost:5080");

record BuyRequest(int FlightId, string Name, string Passport, TravelClass Class, string? Seat);
record PassportRequest(string Passport);
