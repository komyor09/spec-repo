using SkyWay.Models;

namespace SkyWay.Services;

public class BookingService
{
    private readonly Database _db;
    public BookingService(Database db) => _db = db;

    public Flight? GetFlight(int id) => _db.Flights.FirstOrDefault(f => f.Id == id);

    /// <summary>Поиск будущих рейсов. Пустые параметры означают «любой».</summary>
    public List<Flight> Search(string? from, string? to, DateTime? date) =>
        _db.Flights
            .Where(f => f.Departure > DateTime.Now)
            .Where(f => string.IsNullOrWhiteSpace(from) || f.From.Contains(from.Trim(), StringComparison.OrdinalIgnoreCase))
            .Where(f => string.IsNullOrWhiteSpace(to) || f.To.Contains(to.Trim(), StringComparison.OrdinalIgnoreCase))
            .Where(f => date == null || f.Departure.Date == date.Value.Date)
            .OrderBy(f => f.Departure)
            .ToList();

    public List<string> FreeSeats(Flight flight, TravelClass cls)
    {
        var (prefix, count) = cls == TravelClass.Economy ? ("E", flight.EconomySeats) : ("B", flight.BusinessSeats);
        var taken = _db.Tickets
            .Where(t => t.FlightId == flight.Id && !t.Cancelled)
            .Select(t => t.Seat)
            .ToHashSet();
        return Enumerable.Range(1, count).Select(i => $"{prefix}{i}").Where(s => !taken.Contains(s)).ToList();
    }

    public Ticket Buy(Flight flight, string name, string passport, TravelClass cls, string? seat)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Укажите имя пассажира.");
        if (passport.Trim().Length < 6) throw new ArgumentException("Слишком короткий номер документа.");
        if (flight.Departure <= DateTime.Now) throw new InvalidOperationException("Рейс уже вылетел.");

        var free = FreeSeats(flight, cls);
        if (free.Count == 0) throw new InvalidOperationException("В этом классе нет свободных мест.");

        seat = string.IsNullOrWhiteSpace(seat) ? free[0] : seat.Trim().ToUpper();
        if (!free.Contains(seat)) throw new InvalidOperationException($"Место {seat} недоступно.");

        var ticket = new Ticket
        {
            Code = Guid.NewGuid().ToString("N")[..6].ToUpper(),
            FlightId = flight.Id,
            PassengerName = name.Trim(),
            Passport = passport.Trim(),
            Class = cls,
            Seat = seat,
            Price = flight.PriceFor(cls),
            PurchasedAt = DateTime.Now
        };
        _db.Tickets.Add(ticket);
        _db.Save();
        return ticket;
    }

    public List<Ticket> FindByPassport(string passport) =>
        _db.Tickets
            .Where(t => t.Passport.Equals(passport.Trim(), StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(t => t.PurchasedAt)
            .ToList();

    /// <summary>Возврат: 80% стоимости, если до вылета больше 24 часов, иначе 0%.</summary>
    public decimal Cancel(string code, string passport)
    {
        var ticket = _db.Tickets.FirstOrDefault(t =>
            t.Code.Equals(code.Trim(), StringComparison.OrdinalIgnoreCase) &&
            t.Passport.Equals(passport.Trim(), StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("Билет не найден.");

        if (ticket.Cancelled) throw new InvalidOperationException("Билет уже возвращён.");

        var flight = GetFlight(ticket.FlightId)!;
        if (flight.Departure <= DateTime.Now) throw new InvalidOperationException("Рейс уже вылетел.");

        ticket.Cancelled = true;
        _db.Save();
        return flight.Departure - DateTime.Now > TimeSpan.FromHours(24) ? ticket.Price * 0.8m : 0m;
    }

    public Flight AddFlight(string number, string from, string to, DateTime departure, int durationMin,
                            decimal eco, decimal bus, int ecoSeats, int busSeats)
    {
        var flight = new Flight
        {
            Id = _db.Flights.Count == 0 ? 1 : _db.Flights.Max(f => f.Id) + 1,
            Number = number, From = from, To = to,
            Departure = departure, Arrival = departure.AddMinutes(durationMin),
            EconomyPrice = eco, BusinessPrice = bus,
            EconomySeats = ecoSeats, BusinessSeats = busSeats
        };
        _db.Flights.Add(flight);
        _db.Save();
        return flight;
    }
}
