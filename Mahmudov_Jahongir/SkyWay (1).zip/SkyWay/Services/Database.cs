using System.Text.Json;
using SkyWay.Models;

namespace SkyWay.Services;

/// <summary>Хранилище: рейсы и билеты сохраняются в data.json рядом с программой.</summary>
public class Database
{
    private const string FileName = "data.json";
    private static readonly JsonSerializerOptions Options = new() { WriteIndented = true };

    public List<Flight> Flights { get; set; } = new();
    public List<Ticket> Tickets { get; set; } = new();

    public static Database Load()
    {
        if (File.Exists(FileName))
        {
            try
            {
                var db = JsonSerializer.Deserialize<Database>(File.ReadAllText(FileName), Options);
                if (db != null) return db;
            }
            catch (JsonException) { /* повреждённый файл — создадим заново */ }
        }
        var fresh = Seed();
        fresh.Save();
        return fresh;
    }

    public void Save() => File.WriteAllText(FileName, JsonSerializer.Serialize(this, Options));

    /// <summary>Тестовое расписание на 40 дней вперёд (авиакомпании вымышленные).</summary>
    private static Database Seed()
    {
        string[] airlines = { "Скайвэй Эйр", "Орион Эйр", "Горизонт" };
        string[] codes = { "SW", "OR", "GH" };
        (string A, string B, int Minutes, int Price)[] routes =
        {
            ("Душанбе", "Москва", 230, 11900), ("Худжанд", "Москва", 235, 12400),
            ("Душанбе", "Стамбул", 280, 14500), ("Душанбе", "Дубай", 200, 10900),
            ("Душанбе", "Санкт-Петербург", 300, 13800), ("Москва", "Санкт-Петербург", 85, 4600),
            ("Москва", "Сочи", 170, 7900), ("Москва", "Казань", 95, 5100),
            ("Москва", "Екатеринбург", 165, 8400), ("Москва", "Новосибирск", 255, 12700)
        };
        int[][] slots = { new[] { 6, 30 }, new[] { 13, 15 }, new[] { 20, 40 } };
        var flights = new List<Flight>();

        for (int r = 0; r < routes.Length; r++)
            for (int dir = 0; dir < 2; dir++)
                for (int day = 1; day <= 40; day++)
                    for (int k = 0; k < 2; k++)
                    {
                        var (a, b, minutes, price) = routes[r];
                        if (dir == 1) (a, b) = (b, a);
                        int slot = (r + day + dir + k) % 3;
                        int al = (r + slot + k) % 3;
                        var dep = DateTime.Today.AddDays(day).AddHours(slots[slot][0]).AddMinutes(slots[slot][1]);
                        decimal eco = Math.Round(price * (0.85m + ((day * 7 + r * 13 + slot * 5 + dir * 3) % 10) / 33m) / 100) * 100;
                        flights.Add(new Flight
                        {
                            Id = flights.Count + 1,
                            Number = $"{codes[al]} {100 + r * 10 + slot * 3 + dir}",
                            Airline = airlines[al],
                            From = a, To = b,
                            Departure = dep, Arrival = dep.AddMinutes(minutes),
                            EconomyPrice = eco, BusinessPrice = Math.Round(eco * 2.8m / 100) * 100,
                            EconomySeats = 30, BusinessSeats = 6
                        });
                    }

        return new Database { Flights = flights };
    }
}
