namespace SmartHomeCS;

public sealed class SmartHome
{
    private readonly List<SmartDevice> devices = new();
    public void Add(SmartDevice device) => devices.Add(device);

    public void ShowAll()
    {
        Console.WriteLine("\n--- Устройства ---");
        for (int i = 0; i < devices.Count; i++)
        {
            Console.Write($"{i + 1}. ");
            devices[i].DisplayStatus();
        }
    }

    public void Manage()
    {
        ShowAll();
        Console.Write("Номер устройства: ");
        if (!int.TryParse(Console.ReadLine(), out var index) || index < 1 || index > devices.Count)
        { Console.WriteLine("Некорректный номер."); return; }
        devices[index - 1].Manage();
    }

    public void AllOn()
    {
        foreach (var d in devices)
            if (d is Light or SmartPlug or Camera or AirConditioner) d.TurnOn();
        Console.WriteLine("Устройства включены.");
    }

    public void AllOff()
    {
        foreach (var d in devices)
            if (d is Light or SmartPlug or Camera or AirConditioner) d.TurnOff();
        Console.WriteLine("Устройства выключены.");
    }

    public void LeaveHome()
    {
        foreach (var d in devices)
        {
            if (d is Light or SmartPlug or AirConditioner) d.TurnOff();
            if (d is Camera or DoorLock) d.TurnOn();
            if (d is Curtain curtain) curtain.SetOpening(0);
        }
        Console.WriteLine("Режим «Уход из дома» включён.");
    }

    public void Evening()
    {
        foreach (var d in devices)
        {
            if (d is Light light) { light.TurnOn(); light.SetBrightness(40); }
            if (d is Curtain curtain) curtain.SetOpening(0);
            if (d is AirConditioner ac) { ac.TurnOn(); ac.SetTemperature(23); }
        }
        Console.WriteLine("Режим «Вечер» включён.");
    }

    public void Morning()
    {
        foreach (var d in devices)
        {
            if (d is Light light) { light.TurnOn(); light.SetBrightness(80); }
            if (d is Curtain curtain) curtain.SetOpening(100);
            if (d is AirConditioner ac) ac.TurnOff();
        }
        Console.WriteLine("Режим «Доброе утро» включён.");
    }
}
