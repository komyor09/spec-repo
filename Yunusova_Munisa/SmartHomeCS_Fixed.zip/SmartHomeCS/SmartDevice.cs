namespace SmartHomeCS;

public abstract class SmartDevice
{
    public string Name { get; }
    public bool IsOn { get; protected set; }
    public abstract string DeviceType { get; }

    protected SmartDevice(string name) => Name = name;
    public virtual void TurnOn() => IsOn = true;
    public virtual void TurnOff() => IsOn = false;
    public abstract void DisplayStatus();
    public abstract void Manage();
}
