using SmartHomeCS;

var home = new SmartHome();
home.Add(new Light("Свет в гостиной"));
home.Add(new Light("Свет на кухне"));
home.Add(new Thermostat("Термостат"));
home.Add(new SmartPlug("Розетка телевизора"));
home.Add(new DoorLock("Входная дверь"));
home.Add(new Camera("Камера у входа"));
home.Add(new AirConditioner("Кондиционер"));
home.Add(new Curtain("Шторы в спальне"));

while (true)
{
    Console.Clear();
    Console.WriteLine("========== УМНЫЙ ДОМ ==========");
    Console.WriteLine("1. Список устройств");
    Console.WriteLine("2. Управление устройством");
    Console.WriteLine("3. Сценарий: Уход из дома");
    Console.WriteLine("4. Сценарий: Вечер");
    Console.WriteLine("5. Сценарий: Доброе утро");
    Console.WriteLine("6. Включить все подходящие устройства");
    Console.WriteLine("7. Выключить все подходящие устройства");
    Console.WriteLine("0. Выход");
    Console.Write("Выбор: ");

    switch (Console.ReadLine())
    {
        case "1": home.ShowAll(); Pause(); break;
        case "2": home.Manage(); Pause(); break;
        case "3": home.LeaveHome(); Pause(); break;
        case "4": home.Evening(); Pause(); break;
        case "5": home.Morning(); Pause(); break;
        case "6": home.AllOn(); Pause(); break;
        case "7": home.AllOff(); Pause(); break;
        case "0": return;
        default: Console.WriteLine("Неверный пункт меню."); Pause(); break;
    }
}
static void Pause() { Console.WriteLine("\nНажмите любую клавишу..."); Console.ReadKey(); }
