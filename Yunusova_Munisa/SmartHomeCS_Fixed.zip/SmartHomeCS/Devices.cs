namespace SmartHomeCS;

public sealed class Light : SmartDevice
{
    public int Brightness { get; private set; } = 100;
    public override string DeviceType => "Свет";
    public Light(string name) : base(name) { }
    public void SetBrightness(int value) => Brightness = Math.Clamp(value, 0, 100);
    public override void DisplayStatus() => Console.WriteLine($"{Name}: {(IsOn ? "Включён" : "Выключен")}, яркость {Brightness}%");
    public override void Manage()
    {
        Console.WriteLine("1. Включить  2. Выключить  3. Яркость");
        switch (Console.ReadLine())
        {
            case "1": TurnOn(); break;
            case "2": TurnOff(); break;
            case "3":
                Console.Write("Яркость 0-100: ");
                if (int.TryParse(Console.ReadLine(), out var value)) { SetBrightness(value); TurnOn(); }
                else Console.WriteLine("Введите число.");
                break;
            default: Console.WriteLine("Неверный выбор."); break;
        }
    }
}

public sealed class Thermostat : SmartDevice
{
    public int Temperature { get; private set; } = 22;
    public override string DeviceType => "Термостат";
    public Thermostat(string name) : base(name) { }
    public void SetTemperature(int value) => Temperature = Math.Clamp(value, 5, 35);
    public override void DisplayStatus() => Console.WriteLine($"{Name}: задано {Temperature}°C");
    public override void Manage()
    {
        Console.Write("Температура 5-35°C: ");
        if (int.TryParse(Console.ReadLine(), out var value)) SetTemperature(value);
        else Console.WriteLine("Введите число.");
    }
}

public sealed class SmartPlug : SmartDevice
{
    public override string DeviceType => "Розетка";
    public SmartPlug(string name) : base(name) { }
    public override void DisplayStatus() => Console.WriteLine($"{Name}: {(IsOn ? "Включена" : "Выключена")}");
    public override void Manage() { if (IsOn) TurnOff(); else TurnOn(); }
}

public sealed class DoorLock : SmartDevice
{
    public override string DeviceType => "Дверной замок";
    public DoorLock(string name) : base(name) { }
    public override void DisplayStatus() => Console.WriteLine($"{Name}: {(IsOn ? "Закрыта" : "Открыта")}");
    public override void Manage()
    {
        Console.WriteLine("1. Закрыть  2. Открыть");
        switch (Console.ReadLine()) { case "1": TurnOn(); break; case "2": TurnOff(); break; default: Console.WriteLine("Неверный выбор."); break; }
    }
}

public sealed class Camera : SmartDevice
{
    public override string DeviceType => "Камера";
    public Camera(string name) : base(name) { }
    public override void DisplayStatus() => Console.WriteLine($"{Name}: {(IsOn ? "Активна" : "Не активна")}");
    public override void Manage() { if (IsOn) TurnOff(); else TurnOn(); }
}

public sealed class AirConditioner : SmartDevice
{
    public int Temperature { get; private set; } = 24;
    public override string DeviceType => "Кондиционер";
    public AirConditioner(string name) : base(name) { }
    public void SetTemperature(int value) => Temperature = Math.Clamp(value, 16, 30);
    public override void DisplayStatus() => Console.WriteLine($"{Name}: {(IsOn ? "Включён" : "Выключен")}, температура {Temperature}°C");
    public override void Manage()
    {
        Console.WriteLine("1. Включить  2. Выключить  3. Установить температуру");
        switch (Console.ReadLine())
        {
            case "1": TurnOn(); break;
            case "2": TurnOff(); break;
            case "3":
                Console.Write("Температура 16-30°C: ");
                if (int.TryParse(Console.ReadLine(), out var value)) { SetTemperature(value); TurnOn(); }
                else Console.WriteLine("Введите число.");
                break;
            default: Console.WriteLine("Неверный выбор."); break;
        }
    }
}

public sealed class Curtain : SmartDevice
{
    public int Opening { get; private set; }
    public override string DeviceType => "Шторы";
    public Curtain(string name) : base(name) { }
    public void SetOpening(int value) => Opening = Math.Clamp(value, 0, 100);
    public override void DisplayStatus() => Console.WriteLine($"{Name}: открыты на {Opening}%");
    public override void Manage()
    {
        Console.Write("Открытие 0-100%: ");
        if (int.TryParse(Console.ReadLine(), out var value)) SetOpening(value);
        else Console.WriteLine("Введите число.");
    }
}
