namespace CourierDelivery.Models;

/// <summary>Хрупкая посылка: наценка 30% за аккуратную перевозку.</summary>
public class FragileParcel : Parcel
{
    public FragileParcel(string recipient, string address, decimal weightKg)
        : base(recipient, address, weightKg)
    {
    }

    public override string Type => "Хрупкая";

    public override decimal CalculateCost() => BaseCost * 1.3m;
}
