using CourierDelivery.Exceptions;

namespace CourierDelivery.Models;

/// <summary>Курьер. Следит за своей загрузкой и не берёт посылки сверх грузоподъёмности.</summary>
public class Courier
{
    private static int _nextId = 1;

    private readonly List<Parcel> _parcels = new();

    public Courier(string name, string vehicle, decimal maxLoadKg)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Имя курьера не может быть пустым.", nameof(name));
        if (string.IsNullOrWhiteSpace(vehicle))
            throw new ArgumentException("Укажите транспорт.", nameof(vehicle));
        if (maxLoadKg <= 0)
            throw new ArgumentOutOfRangeException(nameof(maxLoadKg), "Грузоподъёмность должна быть больше нуля.");

        Id = _nextId++;
        Name = name.Trim();
        Vehicle = vehicle.Trim();
        MaxLoadKg = maxLoadKg;
    }

    public int Id { get; }

    public string Name { get; }

    public string Vehicle { get; }

    public decimal MaxLoadKg { get; }

    public decimal CurrentLoadKg => _parcels.Sum(p => p.WeightKg);

    public decimal FreeCapacityKg => MaxLoadKg - CurrentLoadKg;

    public IReadOnlyList<Parcel> Parcels => _parcels;

    public bool CanTake(Parcel parcel) => parcel.WeightKg <= FreeCapacityKg;

    public void Take(Parcel parcel)
    {
        if (!CanTake(parcel))
            throw new CourierCapacityException(Name, FreeCapacityKg, parcel.WeightKg);

        parcel.AssignTo(Id);
        _parcels.Add(parcel);
    }

    public void Release(Parcel parcel) => _parcels.Remove(parcel);

    public override string ToString() =>
        $"[{Id}] {Name} ({Vehicle}), загрузка {CurrentLoadKg:F1}/{MaxLoadKg:F1} кг, посылок: {_parcels.Count}";
}
