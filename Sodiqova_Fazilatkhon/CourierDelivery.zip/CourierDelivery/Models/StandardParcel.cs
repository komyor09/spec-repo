namespace CourierDelivery.Models;

/// <summary>Обычная посылка: стоимость равна базовой.</summary>
public class StandardParcel : Parcel
{
    public StandardParcel(string recipient, string address, decimal weightKg)
        : base(recipient, address, weightKg)
    {
    }

    public override string Type => "Обычная";

    public override decimal CalculateCost() => BaseCost;
}
