namespace CourierDelivery.Models;

public enum DeliveryStatus
{
    Created,    // создана
    Assigned,   // назначен курьер
    InTransit,  // курьер забрал посылку
    Delivered,  // доставлена
    Cancelled   // отменена
}

public static class DeliveryStatusExtensions
{
    public static string ToRussian(this DeliveryStatus status) => status switch
    {
        DeliveryStatus.Created => "Создана",
        DeliveryStatus.Assigned => "Назначена",
        DeliveryStatus.InTransit => "В пути",
        DeliveryStatus.Delivered => "Доставлена",
        DeliveryStatus.Cancelled => "Отменена",
        _ => status.ToString()
    };
}
