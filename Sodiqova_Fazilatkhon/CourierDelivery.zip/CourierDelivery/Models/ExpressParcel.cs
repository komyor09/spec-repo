namespace CourierDelivery.Models;

/// <summary>Экспресс-посылка: наценка 50% и срочный сбор 100 сомони, есть срок доставки.</summary>
public class ExpressParcel : Parcel
{
    public ExpressParcel(string recipient, string address, decimal weightKg, DateTime deadline)
        : base(recipient, address, weightKg)
    {
        if (deadline <= DateTime.Now)
            throw new ArgumentException("Срок доставки должен быть в будущем.", nameof(deadline));

        Deadline = deadline;
    }

    public DateTime Deadline { get; }

    public override string Type => "Экспресс";

    public override decimal CalculateCost() => BaseCost * 1.5m + 100m;

    public bool IsOverdue(DateTime now) =>
        Status != DeliveryStatus.Delivered
        && Status != DeliveryStatus.Cancelled
        && now > Deadline;

    public override string GetDescription() =>
        $"{base.GetDescription()}, срок до {Deadline:dd.MM.yyyy HH:mm}";
}
