namespace CourierDelivery.Exceptions;

/// <summary>Попытка перевести посылку в статус, который для неё недопустим.</summary>
public class DeliveryStateException : Exception
{
    public DeliveryStateException(string message) : base(message)
    {
    }
}
