namespace CourierDelivery.Exceptions;

/// <summary>Посылка тяжелее свободной грузоподъёмности курьера.</summary>
public class CourierCapacityException : Exception
{
    public CourierCapacityException(string courierName, decimal freeKg, decimal requiredKg)
        : base($"Курьер «{courierName}» не может взять посылку: свободно {freeKg:F1} кг, нужно {requiredKg:F1} кг.")
    {
    }
}
